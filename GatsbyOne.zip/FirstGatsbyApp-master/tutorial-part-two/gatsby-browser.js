

require('./src/styles/global.css')