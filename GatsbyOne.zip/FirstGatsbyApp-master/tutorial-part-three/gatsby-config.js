module.exports = {
    plugins: [`gatsby-plugin-typography`],
  }